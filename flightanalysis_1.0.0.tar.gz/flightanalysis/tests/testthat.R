library(testthat)
library(flightanalysis)

test_check("flightanalysis")
